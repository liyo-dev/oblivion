using UnityEngine;

/// <summary>
/// Herramienta de diagnóstico para problemas de colisión de lluvia.
/// Añádelo a un GameObject vacío y ejecuta el diagnóstico desde el Inspector o el menú.
/// </summary>
public class RainCollisionDebugger : MonoBehaviour
{
    [Header("Configuración de Prueba")]
    [SerializeField] private float raycastHeight = 50f;
    [SerializeField] private float raycastSpacing = 5f;
    [SerializeField] private int gridSize = 5;
    [SerializeField] private LayerMask testLayers = ~0;
    
    [Header("Resultados")]
    [SerializeField, TextArea(5, 15)] private string diagnosticResult = "";
    
    [ContextMenu("🔍 Diagnosticar Colisiones del Suelo")]
    public void DiagnoseGroundCollisions()
    {
        var results = new System.Text.StringBuilder();
        results.AppendLine("=== DIAGNÓSTICO DE COLISIÓN DE LLUVIA ===\n");
        
        Vector3 playerPos = transform.position;
        if (Camera.main != null)
        {
            playerPos = Camera.main.transform.position;
        }
        
        int hits = 0;
        int misses = 0;
        
        results.AppendLine($"📍 Centro de prueba: {playerPos}");
        results.AppendLine($"☔ Altura de raycast: {raycastHeight}m");
        results.AppendLine($"🎯 Layers probados: {testLayers.value}\n");
        
        // Hacer una cuadrícula de raycasts
        for (int x = -gridSize; x <= gridSize; x++)
        {
            for (int z = -gridSize; z <= gridSize; z++)
            {
                Vector3 origin = playerPos + new Vector3(x * raycastSpacing, raycastHeight, z * raycastSpacing);
                
                if (Physics.Raycast(origin, Vector3.down, out RaycastHit hit, raycastHeight * 2f, testLayers))
                {
                    hits++;
                    if (x == 0 && z == 0)
                    {
                        results.AppendLine($"✅ Centro: Golpeó '{hit.collider.name}' en layer '{LayerMask.LayerToName(hit.collider.gameObject.layer)}' a altura {hit.point.y:F1}m");
                        results.AppendLine($"   Collider: {hit.collider.GetType().Name}");
                    }
                }
                else
                {
                    misses++;
                    if (x == 0 && z == 0)
                    {
                        results.AppendLine($"❌ Centro: NO HAY COLLIDER debajo del jugador!");
                    }
                }
            }
        }
        
        int total = (gridSize * 2 + 1) * (gridSize * 2 + 1);
        float percentage = (hits / (float)total) * 100f;
        
        results.AppendLine($"\n📊 RESULTADOS:");
        results.AppendLine($"   Aciertos: {hits}/{total} ({percentage:F1}%)");
        results.AppendLine($"   Fallos: {misses}/{total}");
        
        if (percentage < 50f)
        {
            results.AppendLine($"\n⚠️ PROBLEMA DETECTADO:");
            results.AppendLine($"   Menos del 50% del área tiene colliders.");
            results.AppendLine($"   La lluvia necesita colliders para detectar impactos.");
            results.AppendLine($"\n💡 SOLUCIÓN:");
            results.AppendLine($"   1. Asegúrate de que el suelo exterior tenga MeshCollider");
            results.AppendLine($"   2. O añade un Box Collider grande como 'piso invisible'");
        }
        else if (percentage >= 90f)
        {
            results.AppendLine($"\n✅ Los colliders parecen estar bien.");
            results.AppendLine($"   El problema puede ser:");
            results.AppendLine($"   - La altura de emisión de las partículas es muy alta");
            results.AppendLine($"   - Las partículas son muy rápidas y atraviesan el suelo");
            results.AppendLine($"   - El sistema de partículas tiene Simulation Space = Local");
        }
        
        // Buscar ParticleSystems de lluvia
        results.AppendLine($"\n=== SISTEMAS DE PARTÍCULAS ENCONTRADOS ===");
        var particleSystems = FindObjectsByType<ParticleSystem>();
        int rainSystems = 0;
        
        foreach (var ps in particleSystems)
        {
            if (ps.name.ToLower().Contains("rain") || ps.transform.root.name.ToLower().Contains("rain"))
            {
                rainSystems++;
                var collision = ps.collision;
                var main = ps.main;
                
                results.AppendLine($"\n🌧️ {ps.name}:");
                results.AppendLine($"   Colisión activada: {collision.enabled}");
                if (collision.enabled)
                {
                    results.AppendLine($"   Tipo: {collision.type}");
                    results.AppendLine($"   Calidad: {collision.quality}");
                    results.AppendLine($"   RadiusScale: {collision.radiusScale}");
                }
                results.AppendLine($"   Simulation Space: {main.simulationSpace}");
                results.AppendLine($"   Start Speed: {main.startSpeed.constant}");
            }
        }
        
        if (rainSystems == 0)
        {
            results.AppendLine("   ⚠️ No se encontraron sistemas de partículas de lluvia activos.");
        }
        
        diagnosticResult = results.ToString();
        Debug.Log(diagnosticResult);
    }
    
    [ContextMenu("🎯 Crear Plano de Colisión de Prueba")]
    public void CreateTestCollisionPlane()
    {
        var existing = GameObject.Find("_RainCollisionTestPlane");
        if (existing != null)
        {
            DestroyImmediate(existing);
            Debug.Log("🗑️ Plano de prueba eliminado.");
            return;
        }
        
        var plane = GameObject.CreatePrimitive(PrimitiveType.Plane);
        plane.name = "_RainCollisionTestPlane";
        plane.transform.position = new Vector3(transform.position.x, transform.position.y - 1f, transform.position.z);
        plane.transform.localScale = new Vector3(10f, 1f, 10f); // 100x100 metros
        
        // Hacerlo invisible pero con collider
        var renderer = plane.GetComponent<MeshRenderer>();
        renderer.enabled = false;
        
        Debug.Log("✅ Plano de colisión de prueba creado. Si la lluvia ahora colisiona, el problema es que falta collider en el suelo exterior.");
        Debug.Log("💡 Ejecuta de nuevo para eliminar el plano de prueba.");
    }
    
#if UNITY_EDITOR
    private void OnDrawGizmosSelected()
    {
        Vector3 center = transform.position;
        if (Camera.main != null)
            center = Camera.main.transform.position;
            
        Gizmos.color = new Color(0, 1, 1, 0.3f);
        
        // Dibujar área de prueba
        Vector3 size = new Vector3(gridSize * raycastSpacing * 2, 0.1f, gridSize * raycastSpacing * 2);
        Gizmos.DrawCube(center + Vector3.up * raycastHeight, size);
        
        // Dibujar rayos
        Gizmos.color = Color.yellow;
        for (int x = -gridSize; x <= gridSize; x += gridSize)
        {
            for (int z = -gridSize; z <= gridSize; z += gridSize)
            {
                Vector3 origin = center + new Vector3(x * raycastSpacing, raycastHeight, z * raycastSpacing);
                Gizmos.DrawLine(origin, origin + Vector3.down * raycastHeight * 2);
            }
        }
    }
#endif
}

