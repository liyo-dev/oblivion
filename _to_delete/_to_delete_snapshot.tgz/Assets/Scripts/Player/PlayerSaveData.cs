using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class PlayerSaveData
{
    public string lastSpawnAnchorId;

    public int level;
    public float maxHp, currentHp;
    public float maxMp, currentMp;

    // Hechizos/skills
    public List<AbilityId> abilities = new();
    public List<SpellId>   spells    = new();
    public List<string>    flags     = new(); // misiones/estados simples
    public List<InventoryItemSave> inventory = new();
    public List<string> defeatedBossIds = new();
    public List<AppearanceEntry> appearance = new();
    public List<string> unlockedWardrobeIds = new();
    public List<string> consumedInteractables = new();
    public List<string> seenLorePopupIds = new();
    
    // === NUEVO: narrativas interactivas completadas ===
    // Permite persistir qué narrativas de un solo uso ya se han ejecutado
    public List<string> completedInteractiveNarratives = new();
    
    // === NUEVO: miembros del equipo (party) ===
    // IDs narrativos de los NPCs que están en el equipo del jugador
    public List<string> partyMemberIds = new();
    
    public int activeCharacterSlot = 1; // 1 = Will por defecto
    
    // === NUEVO: puntos de teletransporte desbloqueados ===
    public List<string> unlockedTeleportPoints = new();
    
    [Serializable]
    public struct NarrativeBlackboardSnapshot
    {
        public string graphLabel;
        public List<SimpleBlackboard.Entry> blackboardData;
    }
    
    public List<NarrativeBlackboardSnapshot> narrativeBlackboards = new();
    
    [Serializable]
    public struct NpcPosEntry
    {
        public string npcId;
        public Vector3 position;
        public Quaternion rotation;
        public bool hasRotation; // FIX INC-028: ver comentario en PlayerPresetSO.NpcPosEntry
        public bool hasActiveState;
        public bool isActive;
    }

    // Posiciones persistidas de NPCs (reflejadas desde/hacia el PlayerPresetSO)
    public List<NpcPosEntry> npcPositions = new();

    // Vínculos sociales forjados en runtime entre NPCs (reflejados desde/hacia NPCRelationshipRegistry
    // vía PlayerPresetSO.npcRelationships). Se reutiliza NPCRelationshipRegistry.SaveEntry directamente.
    public List<NPCRelationshipRegistry.SaveEntry> npcRelationships = new();

    // Slots guardados (opcional: si faltan en saves antiguos, quedarán en None por defecto)
    public SpellId leftSpellId  = SpellId.None;
    public SpellId rightSpellId = SpellId.None;
    public SpellId specialSpellId = SpellId.None;

    // === NUEVO: permisos físicos/acciónales que se persisten por preset ===
    // Si un save antiguo no contiene estos campos, quedarán en false (valor por defecto)
    public bool canSwim;
    public bool canJump;
    public bool canClimb;
    public bool canFly;
    public bool canMagic;

    // Nota: Eliminado el soporte de snapshot narrativo (redundante con flags)

    // ---- Helpers actualizados para usar GameBootProfile ----
    
    /// <summary>
    /// Crea PlayerSaveData a partir del GameBootProfile actual (sincrónico).
    /// Si el profile aún no está disponible, devuelve un objeto vacío y loguea error.
    /// Para esperar al evento, usa FromGameBootProfileWhenReady.
    /// </summary>
    public static PlayerSaveData FromGameBootProfile()
    {
        var bootProfile = GameBootService.Profile;
        if (bootProfile == null)
        {
            Debug.LogError("[PlayerSaveData] GameBootService.Profile es null (¿se llamó antes de OnProfileReady?)");
            return new PlayerSaveData();
        }

        var preset = bootProfile.GetActivePresetResolved();
        if (preset == null)
        {
            Debug.LogError("[PlayerSaveData] No hay preset activo en GameBootProfile");
            return new PlayerSaveData();
        }

        var d = new PlayerSaveData();
        var activeAnchor = preset.spawnAnchorId;
        d.lastSpawnAnchorId = SpawnManager.CurrentAnchorId ?? activeAnchor ?? "Bedroom";

        // Obtener datos desde el preset activo
        d.level = preset.level;
        d.maxHp = preset.maxHP;
        d.currentHp = preset.currentHP;
        d.maxMp = preset.maxMP;
        d.currentMp = preset.currentMP;

        d.abilities = new List<AbilityId>(preset.unlockedAbilities ?? new List<AbilityId>());
        d.spells = new List<SpellId>(preset.unlockedSpells ?? new List<SpellId>());
        d.flags = new List<string>(preset.flags ?? new List<string>());
        d.inventory = preset.inventoryItems != null ? new List<InventoryItemSave>(preset.inventoryItems) : new List<InventoryItemSave>();
        d.defeatedBossIds = preset.defeatedBossIds != null ? new List<string>(preset.defeatedBossIds) : new List<string>();
        d.appearance = preset.appearance != null ? new List<AppearanceEntry>(preset.appearance) : new List<AppearanceEntry>();
        d.unlockedWardrobeIds = preset.unlockedWardrobeIds != null ? new List<string>(preset.unlockedWardrobeIds) : new List<string>();
        d.consumedInteractables = preset.consumedInteractableIds != null ? new List<string>(preset.consumedInteractableIds) : new List<string>();
        d.seenLorePopupIds = preset.seenLorePopupIds != null ? new List<string>(preset.seenLorePopupIds) : new List<string>();
        d.completedInteractiveNarratives = preset.completedInteractiveNarratives != null ? new List<string>(preset.completedInteractiveNarratives) : new List<string>();
        
        // DEBUG: Ver qué narrativas se están guardando
        Debug.Log($"[PlayerSaveData] 💾 FromGameBootProfile - completedInteractiveNarratives: {d.completedInteractiveNarratives.Count} entradas");
        if (d.completedInteractiveNarratives.Count > 0)
        {
            foreach (var id in d.completedInteractiveNarratives)
            {
                Debug.Log($"[PlayerSaveData]   → {id}");
            }
        }
        
        d.narrativeBlackboards = preset.narrativeBlackboards != null ? new List<NarrativeBlackboardSnapshot>(preset.narrativeBlackboards) : new List<NarrativeBlackboardSnapshot>();
        
        // Party members - obtener directamente del PlayerParty si existe
        if (Game.NPC.PlayerParty.HasInstance)
        {
            d.partyMemberIds = Game.NPC.PlayerParty.Instance.GetMemberIdsForSave();
            Debug.Log($"[PlayerSaveData] 💾 Party guardado: {d.partyMemberIds.Count} miembros");
        }
        else
        {
            d.partyMemberIds = preset.partyMemberIds != null ? new List<string>(preset.partyMemberIds) : new List<string>();
        }
        
        d.activeCharacterSlot = preset.activeCharacterSlot;
        
        // NPCs
        if (preset.npcPositions != null && preset.npcPositions.Count > 0)
        {
            d.npcPositions = new List<NpcPosEntry>(preset.npcPositions.Count);
            for (int i = 0; i < preset.npcPositions.Count; i++)
            {
                var e = preset.npcPositions[i];
                d.npcPositions.Add(new NpcPosEntry
                {
                    npcId = e.npcId,
                    position = e.position,
                    rotation = e.rotation,
                    hasActiveState = e.hasActiveState,
                    isActive = e.isActive
                });
            }
        }

        // Slots
        d.leftSpellId = preset.leftSpellId;
        d.rightSpellId = preset.rightSpellId;
        d.specialSpellId = preset.specialSpellId;

        // === NUEVO: persistir permisos de abilities desde el preset ===
        if (preset.abilities != null)
        {
            d.canSwim = preset.abilities.swim;
            d.canJump = preset.abilities.jump;
            d.canClimb = preset.abilities.climb;
            d.canFly = preset.abilities.fly;
            d.canMagic = preset.abilities.magic;
        }

        // === NUEVO: persistir puntos de teletransporte desbloqueados ===
        // Leer desde el preset (que se sincroniza automáticamente al desbloquear puntos)
        // Fallback a TeleportRegistry.ToSaveData() por compatibilidad
        d.unlockedTeleportPoints = preset.unlockedTeleportPoints != null && preset.unlockedTeleportPoints.Count > 0
            ? new List<string>(preset.unlockedTeleportPoints)
            : TeleportRegistry.ToSaveData();
        Debug.Log($"[PlayerSaveData] 💾 Teleport points guardados: {d.unlockedTeleportPoints.Count}");

        // === NUEVO: persistir vínculos sociales forjados en runtime entre NPCs ===
        d.npcRelationships = NPCRelationshipRegistry.ToSaveEntries();

        return d;
    }

    /// <summary>
    /// Variante event-driven: espera a GameBootService.OnProfileReady (si hace falta) y devuelve el resultado por callback.
    /// Si el profile ya está disponible, llama al callback inmediatamente.
    /// </summary>
    public static void FromGameBootProfileWhenReady(Action<PlayerSaveData> onReady)
    {
        if (GameBootService.IsAvailable)
        {
            onReady?.Invoke(FromGameBootProfile());
            return;
        }

        void Handler()
        {
            GameBootService.OnProfileReady -= Handler;
            onReady?.Invoke(FromGameBootProfile());
        }

        GameBootService.OnProfileReady += Handler;
    }

    /// <summary>
    /// Aplica estos datos al GameBootProfile (actualiza runtimePreset) de forma sincrónica.
    /// Para esperar a OnProfileReady, usa ApplyToGameBootProfileWhenReady.
    /// </summary>
    public void ApplyToGameBootProfile()
    {
        var bootProfile = GameBootService.Profile;
        if (bootProfile == null)
        {
            Debug.LogError("[PlayerSaveData] GameBootService.Profile es null (¿se llamó antes de OnProfileReady?)");
            return;
        }

        // Usar el método existente del GameBootProfile para aplicar los datos
        bootProfile.SetRuntimePresetFromSave(this);
        
        Debug.Log($"[PlayerSaveData] Datos aplicados al GameBootProfile - Level: {level}, HP: {currentHp}/{maxHp}");
    }

    /// <summary>
    /// Variante event-driven: espera a GameBootService.OnProfileReady (si hace falta) y luego aplica los datos.
    /// onApplied(true) si se aplicó, false si no.
    /// </summary>
    public void ApplyToGameBootProfileWhenReady(Action<bool> onApplied = null)
    {
        if (GameBootService.IsAvailable)
        {
            ApplyToGameBootProfile();
            onApplied?.Invoke(true);
            return;
        }

        void Handler()
        {
            GameBootService.OnProfileReady -= Handler;
            if (GameBootService.Profile == null)
            {
                onApplied?.Invoke(false);
                return;
            }
            ApplyToGameBootProfile();
            onApplied?.Invoke(true);
        }

        GameBootService.OnProfileReady += Handler;
    }
}