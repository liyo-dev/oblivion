﻿﻿using UnityEngine;
using DG.Tweening;

/// <summary>
/// Sistema que maneja las colisiones entre proyectiles del jugador y enemigos.
/// Cuando dos proyectiles colisionan, se empujan mutuamente, reproducen VFX y se destruyen.
/// </summary>
public static class ProjectileCollisionHandler
{
    /// <summary>
    /// Configuración global de colisiones entre proyectiles
    /// </summary>
    [System.Serializable]
    public class CollisionConfig
    {
        [Header("Fuerzas de Empuje")]
        [Tooltip("OBSOLETO: ya no se usa para el jugador (ver 'Lanzamiento Aéreo' más abajo). Se mantiene solo por compatibilidad con assets ya serializados.")]
        public float playerKnockbackForce = 8f;
        
        [Tooltip("Fuerza aplicada al NPC cuando su proyectil colisiona")]
        public float npcKnockbackForce = 8f;
        
        [Header("VFX")]
        [Tooltip("Prefab del VFX que se reproduce en el punto de colisión")]
        public GameObject collisionVFX;
        
        [Tooltip("Duración del VFX (0 = autodestrucción del VFX)")]
        public float vfxLifetime = 2f;
        
        [Header("Efectos de Cámara")]
        [Tooltip("Intensidad del camera shake al colisionar")]
        public float cameraShakeIntensity = 0.5f;
        
        [Tooltip("Duración del camera shake")]
        public float cameraShakeDuration = 0.3f;
        
        [Header("Audio")]
        [Tooltip("Clave del SFX para la colisión de proyectiles")]
        public string collisionSFXKey = "ProjectileClash";
        
        [Header("Animaciones")]
        [Tooltip("Nombre de la animación que se reproduce en el jugador al colisionar")]
        public string playerCollisionAnimation = "RollBWD_Battle_RM_NoWeapon";

        [Tooltip("Habilitar reproducción de animaciones al colisionar")]
        public bool enableCollisionAnimations = true;

        [Header("Lanzamiento Aéreo del Jugador (estilo Kingdom Hearts)")]
        [Tooltip("Distancia horizontal hacia atrás del lanzamiento aéreo del jugador")]
        public float playerAerialKnockbackDistance = 3.5f;

        [Tooltip("Altura máxima del arco del lanzamiento aéreo del jugador")]
        public float playerAerialKnockbackHeight = 2.2f;

        [Tooltip("Duración total del lanzamiento aéreo del jugador (subida + caída)")]
        public float playerAerialKnockbackDuration = 0.6f;

        [Header("Mecánica en pruebas (Agosto 2026)")]
        [Tooltip("false (por defecto) = cuando dos hechizos chocan, el jugador reproduce su animación de daño estándar y pierde vida (daño propio + daño del hechizo enemigo). " +
                 "true = comportamiento antiguo, el jugador sale lanzado por el aire (ver ApplyAerialLaunch). Se mantiene el código del lanzamiento aéreo por si se revierte esta prueba.")]
        public bool usePlayerAerialLaunch = false;
    }
    
    private static CollisionConfig _config;
    
    /// <summary>
    /// Inicializa la configuración de colisiones. Llamar desde un ScriptableObject o Manager.
    /// </summary>
    public static void Initialize(CollisionConfig config)
    {
        _config = config;
    }
    
    /// <summary>
    /// Obtiene la configuración actual o una por defecto
    /// </summary>
    private static CollisionConfig GetConfig()
    {
        if (_config == null)
        {
            // Configuración por defecto
            _config = new CollisionConfig
            {
                playerKnockbackForce = 8f,
                npcKnockbackForce = 8f,
                vfxLifetime = 2f,
                cameraShakeIntensity = 0.5f,
                cameraShakeDuration = 0.3f,
                collisionSFXKey = "ProjectileClash",
                playerCollisionAnimation = "RollBWD_Battle_RM_NoWeapon",
                enableCollisionAnimations = true,
                playerAerialKnockbackDistance = 3.5f,
                playerAerialKnockbackHeight = 2.2f,
                playerAerialKnockbackDuration = 0.6f,
                usePlayerAerialLaunch = false
            };
        }
        return _config;
    }
    
    /// <summary>
    /// Maneja la colisión entre un proyectil del jugador y uno del enemigo
    /// </summary>
    /// <param name="playerProjectile">Proyectil del jugador (layer "Projectile")</param>
    /// <param name="enemyProjectile">Proyectil del enemigo (layer "ProjectileEnemy")</param>
    /// <param name="collisionPoint">Punto donde colisionaron</param>
    public static void HandleCollision(
        GameObject playerProjectile, 
        GameObject enemyProjectile, 
        Vector3 collisionPoint)
    {
        var config = GetConfig();

        Debug.Log($"[ProjectileCollision] 💥 Colisión detectada en {collisionPoint}");

        // Sumar el daño de ambos hechizos (el propio del jugador + el del enemigo) ANTES de
        // destruir los proyectiles en el paso 6, para no perder el acceso a sus componentes.
        float totalDamage = GetProjectileDamage(playerProjectile) + GetProjectileDamage(enemyProjectile);

        // 1. Reproducir VFX en el punto de colisión
        SpawnCollisionVFX(collisionPoint, config);

        // 2. Reproducir SFX
        PlayCollisionSound(config);

        // 3. Camera shake para feedback
        ApplyCameraShake(config);

        // 4. Reacción del jugador: animación de daño + pérdida de vida
        if (config.enableCollisionAnimations)
        {
            ApplyPlayerReaction(totalDamage, config);
        }

        // 5. Aplicar knockback a jugador y NPC
        ApplyKnockbackToEntities(playerProjectile, enemyProjectile, collisionPoint, config);

        // 6. Destruir ambos proyectiles
        DestroyProjectiles(playerProjectile, enemyProjectile);
    }

    /// <summary>
    /// Lee el daño configurado del proyectil, sea del jugador (MagicProjectile) o del enemigo (EnemyProjectile).
    /// </summary>
    private static float GetProjectileDamage(GameObject projectile)
    {
        if (projectile == null) return 0f;

        var magicProj = projectile.GetComponent<MagicProjectile>();
        if (magicProj != null) return magicProj.Damage;

        var enemyProj = projectile.GetComponent<EnemyProjectile>();
        if (enemyProj != null) return enemyProj.Damage;

        return 0f;
    }
    
    private static void SpawnCollisionVFX(Vector3 position, CollisionConfig config)
    {
        if (config.collisionVFX == null)
        {
            Debug.LogWarning("[ProjectileCollision] No hay VFX configurado para la colisión");
            return;
        }
        
        GameObject vfx = Object.Instantiate(config.collisionVFX, position, Quaternion.identity);
        
        // 🔥 CORRECCIÓN: Siempre destruir el VFX después de un tiempo
        float destroyTime = config.vfxLifetime > 0f ? config.vfxLifetime : 3f; // 3s por defecto
        Object.Destroy(vfx, destroyTime);
        
        Debug.Log($"[ProjectileCollision] ✨ VFX spawneado en {position}");
    }
    
    private static void PlayCollisionSound(CollisionConfig config)
    {
        if (string.IsNullOrEmpty(config.collisionSFXKey))
            return;
        
        if (AudioService.Instance != null)
        {
            AudioService.Instance.PlaySFX(config.collisionSFXKey);
            Debug.Log($"[ProjectileCollision] 🔊 SFX reproducido: {config.collisionSFXKey}");
        }
    }
    
    private static void ApplyCameraShake(CollisionConfig config)
    {
        if (config.cameraShakeIntensity > 0f && config.cameraShakeDuration > 0f)
        {
            Sendero.Core.Feedback.FeedbackService.CameraShake(
                config.cameraShakeIntensity, 
                config.cameraShakeDuration);
            
            Debug.Log($"[ProjectileCollision] 📹 Camera shake aplicado: {config.cameraShakeIntensity}");
        }
    }
    
    /// <summary>
    /// Reacción del jugador ante un choque de hechizos. Mecánica en pruebas (Agosto 2026):
    /// por defecto (usePlayerAerialLaunch = false) el jugador recibe daño = suma del daño de
    /// ambos hechizos (el propio + el del enemigo) y reproduce su animación de daño estándar vía
    /// PlayerHealthSystem.TakeDamage (que ya gestiona animación, VFX, sonido, invulnerabilidad y
    /// knockback simple). Si usePlayerAerialLaunch = true se conserva el comportamiento antiguo:
    /// el jugador sale lanzado por el aire (ver ApplyAerialLaunch).
    /// </summary>
    private static void ApplyPlayerReaction(float totalDamage, CollisionConfig config)
    {
        Debug.Log($"[ProjectileCollision] 🎬 ApplyPlayerReaction INICIADO (usePlayerAerialLaunch={config.usePlayerAerialLaunch}, totalDamage={totalDamage})");

        if (!PlayerService.TryGetPlayer(out var playerGo, allowSceneLookup: true) || playerGo == null)
        {
            Debug.LogWarning($"[ProjectileCollision] ⚠️ Player NO encontrado");
            return;
        }

        Debug.Log($"[ProjectileCollision] ✅ Player encontrado: '{playerGo.name}'");

        if (config.usePlayerAerialLaunch)
        {
            PlayAnimationOnTarget(playerGo, config.playerCollisionAnimation, "Player", config);
            return;
        }

        var playerHealth = playerGo.GetComponent<PlayerHealthSystem>() ?? playerGo.GetComponentInParent<PlayerHealthSystem>();
        if (playerHealth == null)
        {
            Debug.LogWarning($"[ProjectileCollision] ⚠️ Player '{playerGo.name}' no tiene PlayerHealthSystem, no se puede aplicar daño de choque de hechizos");
            return;
        }

        bool applied = playerHealth.TakeDamage(totalDamage);
        Debug.Log($"[ProjectileCollision] 💥 Choque de hechizos: {totalDamage} de daño {(applied ? "aplicado" : "IGNORADO (invulnerable/muerto/god mode)")} al jugador");
    }

    /// <summary>
    /// Reproduce una animación en un GameObject objetivo (Player o NPC).
    /// Solo se usa cuando CollisionConfig.usePlayerAerialLaunch = true (comportamiento antiguo).
    /// </summary>
    private static void PlayAnimationOnTarget(GameObject target, string animationName, string targetType, CollisionConfig config)
    {
        Debug.Log($"[ProjectileCollision] 🎬 PlayAnimationOnTarget INICIADO para {targetType}");
        Debug.Log($"[ProjectileCollision]   - Target: {(target != null ? $"'{target.name}'" : "NULL")}");
        Debug.Log($"[ProjectileCollision]   - Animation: '{animationName}'");
        
        if (string.IsNullOrEmpty(animationName))
        {
            Debug.LogWarning($"[ProjectileCollision] ⚠️ No hay animación configurada para {targetType}");
            return;
        }
        
        if (target == null)
        {
            Debug.LogWarning($"[ProjectileCollision] ⚠️ Target {targetType} es null");
            return;
        }
        
        // Obtener el Animator del target
        var animator = target.GetComponent<Animator>();
        if (animator == null)
        {
            Debug.Log($"[ProjectileCollision] No hay Animator en root, buscando en hijos...");
            animator = target.GetComponentInChildren<Animator>();
        }
        
        if (animator == null)
        {
            Debug.LogError($"[ProjectileCollision] ❌ {targetType} '{target.name}' NO TIENE ANIMATOR en ninguna parte");
            return;
        }
        
        Debug.Log($"[ProjectileCollision] ✅ Animator encontrado en '{animator.gameObject.name}'");
        Debug.Log($"[ProjectileCollision]   - Animator enabled: {animator.enabled}");
        Debug.Log($"[ProjectileCollision]   - Animator isActiveAndEnabled: {animator.isActiveAndEnabled}");
        
        // Reproducir la animación usando PlayInFixedTime para forzar reproducción inmediata
        animator.PlayInFixedTime(animationName, 0, 0f);
        
        Debug.Log($"[ProjectileCollision] 🎬✅ Animación '{animationName}' REPRODUCIDA en {targetType} '{target.name}'");

        // ✅ El JUGADOR sale volando hacia atrás por el aire (ver AerialKnockbackReceiver);
        // el resto de objetivos (NPCs, si algún día se reactiva) usan el desplazamiento simple.
        if (targetType == "Player")
            ApplyAerialLaunch(target, config);
        else
            ApplyKnockbackMovement(target, targetType);
    }

    /// <summary>
    /// Lanza al jugador hacia atrás por el aire (estilo Kingdom Hearts) usando
    /// AerialKnockbackReceiver. La dirección se calcula SIEMPRE respecto al propio forward del
    /// jugador en el momento del impacto: nunca dependemos de la posición del proyectil o del
    /// punto de colisión, que es lo que antes podía hacer que el roll se fuera hacia el lado.
    /// </summary>
    private static void ApplyAerialLaunch(GameObject player, CollisionConfig config)
    {
        if (player == null) return;

        var receiver = player.GetComponent<AerialKnockbackReceiver>();
        if (receiver == null)
            receiver = player.AddComponent<AerialKnockbackReceiver>();

        Vector3 backward = -player.transform.forward;

        receiver.Launch(
            backward,
            config.playerAerialKnockbackDistance,
            config.playerAerialKnockbackHeight,
            config.playerAerialKnockbackDuration);

        Debug.Log($"[ProjectileCollision] 🚀 Lanzamiento aéreo hacia atrás aplicado al jugador (distancia={config.playerAerialKnockbackDistance}m, altura={config.playerAerialKnockbackHeight}m)");
    }

    /// <summary>
    /// Aplica un desplazamiento hacia atrás al objetivo (para que el roll se vea físicamente)
    /// </summary>
    private static void ApplyKnockbackMovement(GameObject target, string targetType)
    {
        const float knockbackDistance = 3f; // Metros hacia atrás
        const float knockbackDuration = 0.5f; // Duración del desplazamiento
        
        // Dirección hacia atrás del objetivo
        Vector3 backwardDirection = -target.transform.forward;
        Vector3 targetPos = target.transform.position + (backwardDirection * knockbackDistance);
        
        // Intentar mover con NavMeshAgent si existe (NPCs)
        var agent = target.GetComponent<UnityEngine.AI.NavMeshAgent>();
        if (agent != null && agent.isActiveAndEnabled && agent.isOnNavMesh)
        {
            Debug.Log($"[ProjectileCollision] 🏃 Aplicando desplazamiento a {targetType} con NavMeshAgent");
            
            // Validar posición en NavMesh
            if (UnityEngine.AI.NavMesh.SamplePosition(targetPos, out var hit, knockbackDistance + 2f, UnityEngine.AI.NavMesh.AllAreas))
            {
                targetPos = hit.position;
            }
            
            // Desactivar temporalmente el agente y moverlo con DOTween
            agent.isStopped = true;
            agent.updatePosition = false;
            agent.updateRotation = false;
            
            target.transform.DOMove(targetPos, knockbackDuration)
                .SetEase(Ease.OutQuad)
                .OnComplete(() =>
                {
                    if (agent != null && agent.isActiveAndEnabled)
                    {
                        agent.isStopped = false;
                        agent.updatePosition = true;
                        agent.updateRotation = true;
                    }
                });
            
            return;
        }
        
        // Si no hay NavMeshAgent, intentar con CharacterController (Player)
        var controller = target.GetComponent<CharacterController>();
        if (controller != null)
        {
            Debug.Log($"[ProjectileCollision] 🏃 Aplicando desplazamiento a {targetType} con CharacterController");
            
            // Mover el transform directamente (CharacterController se ajustará)
            target.transform.DOMove(targetPos, knockbackDuration).SetEase(Ease.OutQuad);
            return;
        }
        
        // Si no hay NavMeshAgent ni CharacterController, intentar con Rigidbody
        var rb = target.GetComponent<Rigidbody>();
        if (rb != null)
        {
            Debug.Log($"[ProjectileCollision] 🏃 Aplicando impulso a {targetType} con Rigidbody");
            rb.AddForce(backwardDirection * knockbackDistance * 2f, ForceMode.Impulse);
            return;
        }
        
        // Último recurso: mover el transform directamente con DOTween
        Debug.Log($"[ProjectileCollision] 🏃 Moviendo {targetType} directamente con Transform");
        target.transform.DOMove(targetPos, knockbackDuration).SetEase(Ease.OutQuad);
    }
    
    /// <summary>
    /// Busca el NPC más cercano al proyectil enemigo usando el registro de combate activo
    /// ⭐ DEPRECATED - Ya no se usa porque el NPC no hace roll
    /// </summary>
    [System.Obsolete("Ya no se usa - el NPC no hace animación de roll")]
    private static GameObject FindNearbyNPC(GameObject enemyProjectile)
    {
        if (enemyProjectile == null)
        {
            Debug.LogWarning("[ProjectileCollision] ⚠️ Proyectil enemigo es null, no se puede buscar NPC");
            return null;
        }
        
        Debug.Log($"[ProjectileCollision] 🔍 FindNearbyNPC: Buscando NPC en combate cercano a '{enemyProjectile.name}'");
        Debug.Log($"[ProjectileCollision]   - Posición proyectil: {enemyProjectile.transform.position}");
        Debug.Log($"[ProjectileCollision]   - NPCs registrados en combate: {ActiveCombatRegistry.Count}");
        
        // ✅ Usar el registro de combate para encontrar NPCs activos
        GameObject npc = ActiveCombatRegistry.GetClosestCombatNPC(
            enemyProjectile.transform.position, 
            maxDistance: 50f
        );
        
        if (npc != null)
        {
            float dist = Vector3.Distance(npc.transform.position, enemyProjectile.transform.position);
            Debug.Log($"[ProjectileCollision] ✅ NPC en combate encontrado: '{npc.name}' a {dist:F1}m");
            Debug.Log($"[ProjectileCollision]   - Posición NPC: {npc.transform.position}");
        }
        else
        {
            Debug.LogWarning($"[ProjectileCollision] ⚠️ NO hay NPCs en combate cerca del proyectil");
            Debug.LogWarning($"[ProjectileCollision]   - Verifica que el NPC haya llamado a EnterCombat()");
            Debug.LogWarning($"[ProjectileCollision]   - Verifica que el NPC tenga NPCBehaviourManagerV2");
        }
        
        return npc;
    }
    
    private static void ApplyKnockbackToEntities(
        GameObject playerProjectile,
        GameObject enemyProjectile,
        Vector3 collisionPoint,
        CollisionConfig config)
    {
        // ⚠️ El knockback del JUGADOR ya NO se aplica aquí con un impulso de Rigidbody: ese cálculo
        // usaba el vector (posición del proyectil del jugador − punto de colisión), que no tiene
        // relación con el forward del jugador y podía apuntar hacia el lado. Ahora el jugador sale
        // volando hacia atrás por el aire vía AerialKnockbackReceiver, disparado desde
        // PlayAnimationOnTarget() con una dirección estrictamente -transform.forward (ver
        // ApplyAerialLaunch). Aquí solo queda el knockback del NPC.
        Vector3 enemyDirection = (enemyProjectile.transform.position - collisionPoint).normalized;
        ApplyKnockbackToNPC(enemyProjectile, enemyDirection, config.npcKnockbackForce);
    }

    private static void ApplyKnockbackToNPC(GameObject enemyProjectile, Vector3 direction, float force)
    {
        // El proyectil del enemigo debería tener referencia real a su instigador (pendiente:
        // requeriría añadir el campo en EnemyProjectile y setearlo en cada AI que lo spawnea).
        // Mientras tanto, usamos el registro de combate activo (mismo patrón que el resto del
        // proyecto, ver ActiveCombatRegistry.GetClosestCombatNPC) en vez de Physics.OverlapSphere:
        // evita la allocation y limita la búsqueda a NPCs realmente en combate, no a cualquier
        // collider en la layer Enemy/Boss en 30m a la redonda.
        GameObject closestNPC = ActiveCombatRegistry.GetClosestCombatNPC(
            enemyProjectile.transform.position,
            maxDistance: 30f);

        if (closestNPC != null)
        {
            var rb = closestNPC.GetComponent<Rigidbody>();
            if (rb != null && !rb.isKinematic)
            {
                // Aplicar fuerza horizontal
                Vector3 knockback = direction;
                knockback.y = 0f;
                knockback = knockback.normalized * force;
                
                rb.AddForce(knockback, ForceMode.Impulse);
                Debug.Log($"[ProjectileCollision] 👊 Knockback aplicado al NPC '{closestNPC.name}': {knockback}");
            }
            else
            {
                Debug.LogWarning($"[ProjectileCollision] El NPC '{closestNPC.name}' no tiene Rigidbody o es kinematic");
            }
        }
        else
        {
            Debug.LogWarning("[ProjectileCollision] No se encontró NPC cercano para aplicar knockback");
        }
    }
    
    private static void DestroyProjectiles(GameObject playerProjectile, GameObject enemyProjectile)
    {
        if (playerProjectile != null)
        {
            var magicProj = playerProjectile.GetComponent<MagicProjectile>();
            if (magicProj != null)
            {
                magicProj.End(true); // byImpact = true
            }
            else
            {
                Object.Destroy(playerProjectile);
            }
            
            Debug.Log("[ProjectileCollision] 💀 Proyectil del jugador destruido");
        }
        
        if (enemyProjectile != null)
        {
            var enemyProj = enemyProjectile.GetComponent<EnemyProjectile>();
            if (enemyProj != null)
            {
                enemyProj.DestroyProjectile();
            }
            else
            {
                Object.Destroy(enemyProjectile);
            }
            
            Debug.Log("[ProjectileCollision] 💀 Proyectil del enemigo destruido");
        }
    }
}

