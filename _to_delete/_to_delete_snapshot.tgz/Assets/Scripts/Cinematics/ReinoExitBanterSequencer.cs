using System.Collections;
using UnityEngine;
using Game.NPC;

/// Orquestador del banter previo a la salida del Reino:
///   0. Will se detiene; Estela y Liam siguen caminando unos pasos y se giran al notar que no les sigue.
///   1. Liam pregunta qué ocurre.
///   2. Will confiesa que tiene miedo de lo que viene.
///   3. Estela lo anima a su manera.
///   4. Liam le recuerda que no está solo.
///   5. Will da las gracias y el grupo retoma la marcha → señal de salida.
/// Señal de entrada: "EVT_REINOEXIT_BANTER_START" (heredada de CinematicSequencerBase._signalIn).
/// OJO: NO es la misma que "EVT_REINO_EXIT_BOUNDARY" que emite KingdomBoundaryTrigger al cruzar
/// el límite físico del Reino. Ese evento crudo lo consume primero el WaitCustomEventNode del
/// grafo (solo llega a él tras iniciar ELDRAN_MISSION14); el propio grafo re-emite entonces
/// "EVT_REINOEXIT_BANTER_START" mediante un RaiseCustomEventNode. Si este sequencer escuchara
/// directamente "EVT_REINO_EXIT_BOUNDARY" (como ocurría antes), reaccionaría al cruce físico
/// crudo aunque el grafo aún no hubiera llegado a ese punto (p.ej. cruzando el límite antes de
/// tiempo en testeo), porque CinematicSequencerBase.Awake() se suscribe sin comprobar el estado
/// narrativo. Mantener esta separación de claves es lo que garantiza que el banter solo se
/// dispare cuando el grafo realmente está en ese punto.
/// Señal de salida: heredada de CinematicSequencerBase._signalOut ("EVT_REINOEXIT_BANTER_DONE").
/// El WaitCustomEventNode antes de KingdomExitTransitionNode espera esta señal de salida, para
/// que el corte de cámara + logo llegue después del banter y no en paralelo.
[DisallowMultipleComponent]
public class ReinoExitBanterSequencer : CinematicSequencerBase
{
    [Header("Personajes — IDs de party (NPCBehaviourManagerV2.DialogueCharacterId)")]
    [Tooltip("DialogueCharacterId de Estela (para localizarla en PlayerParty en tiempo real).")]
    [SerializeField] private string _estelaCharacterId = "CHAR_ESTELA";

    [Tooltip("DialogueCharacterId de Liam (para localizarlo en PlayerParty en tiempo real).")]
    [SerializeField] private string _liamCharacterId = "CHAR_LIAM";

    [Header("Cámara — planos (dejar vacíos = sin corte, se queda en el plano anterior)")]
    [Tooltip("Plano general mientras el grupo camina, al entrar en la secuencia.")]
    [SerializeField] private Transform _shotWalkGroup;
    [Tooltip("Primer plano de Will — Fase 2 (confiesa su miedo)")]
    [SerializeField] private Transform _shotWillClose;
    [Tooltip("Primer plano de Estela — Fase 3 (lo anima)")]
    [SerializeField] private Transform _shotEstelaClose;
    [Tooltip("Primer plano de Liam — Fases 1 y 4 (pregunta / apoyo)")]
    [SerializeField] private Transform _shotLiamClose;

    [Header("Decoración — pétalos al iniciar")]
    [Tooltip("Prefabs de pétalos a esparcir al arrancar la secuencia (mismos assets que decoran el Reino en MainWorld: Assets/Art/World/Fantasy_Kingdom_Pack/Particle/Petal01_P y Petal02_P). Se reproducen vía VfxPoolService, nunca con Instantiate/Destroy directo (ver CLAUDE.md §2). Vacío = sin decoración.")]
    [SerializeField] private GameObject[] _petalDecorPrefabs;
    [Tooltip("Puntos manuales donde aparecen los pétalos (uno por prefab/punto). Si se asigna, tiene prioridad sobre el reparto automático por pantalla de abajo. Dejar vacío para el efecto \"viento por toda la pantalla\".")]
    [SerializeField] private Transform[] _petalSpawnPoints;
    [Tooltip("Duración de cada instancia de pétalos. Con margen de sobra sobre la duración típica del banter (los diálogos paginados pueden alargarse según el idioma); si en playtest la secuencia dura más, subir este valor.")]
    [SerializeField] private float _petalsLifetime = 45f;

    [Header("Decoración — reparto por pantalla (si no hay _petalSpawnPoints)")]
    [Tooltip("Cuántas instancias de pétalos se reparten por delante de la cámara para cubrir toda la pantalla.")]
    [SerializeField] private int _petalScreenCount = 24;
    [Tooltip("Ancho x alto (en unidades de mundo) del área frente a la cámara donde se reparten los pétalos. Súbelo si quedan huecos sin cubrir en los bordes de pantalla.")]
    [SerializeField] private Vector2 _petalScreenSpread = new Vector2(16f, 9f);
    [Tooltip("Distancia mínima/máxima delante de la cámara a la que aparecen (varias profundidades = sensación de volumen, no un plano plano).")]
    [SerializeField] private Vector2 _petalScreenDepthRange = new Vector2(4f, 14f);

    [Header("Decoración — viento (rollo Pocahontas)")]
    [Tooltip("Dirección del viento en espacio de CÁMARA: x = hacia la derecha de pantalla (negativo = izquierda), y = hacia arriba de pantalla, z = alejándose de cámara. Se normaliza sola, solo importa la proporción entre ejes.")]
    [SerializeField] private Vector3 _petalWindDirectionCameraSpace = new Vector3(-1f, 0.2f, 0f);
    [Tooltip("Velocidad del viento en unidades/seg. ApplyWind() anula la gravedad y el impulso inicial aleatorio del prefab para que esta dirección se vea claramente, así que puede quedar más lento de lo que parece necesario.")]
    [SerializeField] private float _petalWindSpeed = 3.5f;

    // ── Fase 0 — Will se detiene; Estela y Liam siguen caminando y se giran ──────

    [Header("Fase 0 — Estela y Liam continúan y se giran")]
    [Tooltip("Punto al que camina Estela antes de girarse hacia Will.")]
    [SerializeField] private Transform _estelaContinueTarget;
    [Tooltip("Punto al que camina Liam antes de girarse hacia Will.")]
    [SerializeField] private Transform _liamContinueTarget;
    [SerializeField] private float _continueWalkDuration = 1.5f;
    [SerializeField] private float _continueWalkMaxDuration = 6f;

    // ── Fase 1 — Liam pregunta ───────────────────────────────────────────────────

    [Header("Fase 1 — Liam pregunta")]
    [SerializeField] private string _keyLiamPregunta = "EVT_REINOEXIT_LIAM_01";
    [SerializeField] private float _liamPreguntaDuration = 2.5f;
    [SerializeField] private string _animLiamPregunta;

    // ── Fase 2 — Will confiesa su miedo ─────────────────────────────────────────

    [Header("Fase 2 — Will confiesa su miedo (líneas separadas por '\\n' en la localización)")]
    [SerializeField] private string _keyWillMiedo = "EVT_REINOEXIT_WILL_01";
    [SerializeField] private float _willMiedoDurationPerPage = 2.5f;
    [SerializeField] private string _animWillMiedo;

    // ── Fase 3 — Estela lo anima ────────────────────────────────────────────────

    [Header("Fase 3 — Estela lo anima (líneas separadas por '\\n' en la localización)")]
    [SerializeField] private string _keyEstelaAnimo = "EVT_REINOEXIT_ESTELA_01";
    [SerializeField] private float _estelaAnimoDurationPerPage = 2.5f;
    [SerializeField] private string _animEstelaAnimo;

    // ── Fase 4 — Liam lo apoya ───────────────────────────────────────────────────

    [Header("Fase 4 — Liam lo apoya (líneas separadas por '\\n' en la localización)")]
    [SerializeField] private string _keyLiamApoyo = "EVT_REINOEXIT_LIAM_02";
    [SerializeField] private float _liamApoyoDurationPerPage = 2.2f;
    [SerializeField] private string _animLiamApoyo;

    // ── Fase 5 — Will da las gracias ────────────────────────────────────────────

    [Header("Fase 5 — Will da las gracias")]
    [SerializeField] private string _keyWillGracias = "EVT_REINOEXIT_WILL_02";
    [SerializeField] private float _willGraciasDuration = 2f;
    [SerializeField] private string _animWillGracias;

    // ── Cache ─────────────────────────────────────────────────────────────────

    private Transform _willTransform;
    private NPCBehaviourManagerV2 _estelaManager;
    private NPCBehaviourManagerV2 _liamManager;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
    [ContextMenu("Test — iniciar sin señal")]
    private void TestStartDirect() => StartCoroutine(Co_Sequence());
#endif

    protected override IEnumerator Co_Sequence()
    {
        ResolveCharacters();

        // Sin transición asignada, esto corta de inmediato sin fundido (ver Co_Transition):
        // el banter arranca en marcha, sin interrumpir la caminata con un negro.
        // SpawnPetalDecor() va como additionalOnCut (no como sentencia suelta después del yield):
        // así se dispara en el MISMO instante en que _cinematicCamera.Cut(_shotWalkGroup) coloca la
        // cámara en el plano del grupo, nunca antes. Si en el futuro se asigna un _entryTransition
        // con fundido, los pétalos seguirán naciendo justo en el punto de corte (pantalla cubierta),
        // no se verán ya cayendo cuando la pantalla se revele.
        yield return Co_BeginCinematicWithTransition(_shotWalkGroup, SpawnPetalDecor);

        // Apagamos la música de gameplay al inicio. PlaySequenceMusic() se retrasa hasta
        // después de la Fase 0 (≈ _continueWalkDuration): para cuando el grupo se gira,
        // la música antigua ya ha terminado su fade y la nueva arranca limpia sin crossfade
        // contra la de gameplay. Si no hay clip de secuencia, la pausa queda en silencio
        // hasta que KingdomExitTransitionNode arranque el tema principal.
        AudioService.Instance?.StopMusic(1.5f);

        // ── Fase 0: Will se detiene; Estela y Liam siguen caminando y se giran ──
        yield return Co_GroupContinuesAndTurns();
        PlaySequenceMusic();

        // ── Fase 1: Liam pregunta ───────────────────────────────────────────────
        yield return Co_LiamPregunta();

        // ── Fase 2: Will confiesa su miedo ──────────────────────────────────────
        yield return Co_WillMiedo();

        // ── Fase 3: Estela lo anima ──────────────────────────────────────────────
        yield return Co_EstelaAnimo();

        // ── Fase 4: Liam lo apoya ─────────────────────────────────────────────────
        yield return Co_LiamApoyo();

        // ── Fase 5: Will da las gracias — cierre y señal de salida ──────────────
        yield return Co_WillGracias();

        yield return Co_EndCinematicWithTransition(() =>
        {
            // Sin RestoreMusic() aquí: KingdomExitTransitionNode corta la música un
            // instante después con StopMusic(). Si esta secuencia primero restaura la
            // música de escena (crossfade propio) y acto seguido el otro nodo la para,
            // los dos crossfades compiten por las mismas fuentes de AudioService y la
            // pista original queda huérfana a medio fundido en vez de llegar a silencio
            // — eso es lo que sonaba como "las dos músicas a la vez".
            RaiseSignalOut();
        });
    }

    private void ResolveCharacters()
    {
        if (PlayerService.TryGetPlayer(out var playerGo, allowSceneLookup: true) && playerGo != null)
            _willTransform = playerGo.transform;

        _estelaManager = FindPartyMember(_estelaCharacterId);
        _liamManager   = FindPartyMember(_liamCharacterId);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        if (_willTransform == null) Debug.LogWarning("[ReinoExitBanterSequencer] No se encontró al jugador (Will).");
        if (_estelaManager == null) Debug.LogWarning($"[ReinoExitBanterSequencer] No se encontró a Estela (id='{_estelaCharacterId}') en PlayerParty.");
        if (_liamManager   == null) Debug.LogWarning($"[ReinoExitBanterSequencer] No se encontró a Liam (id='{_liamCharacterId}') en PlayerParty.");
#endif
    }

    /// <summary>
    /// Esparce pétalos ambientales al arrancar la secuencia (decoración, no gameplay). Un único
    /// disparo por punto configurado vía VfxPoolService — nunca Instantiate/Destroy directo, es el
    /// mismo patrón que un impacto o una explosión, solo que con una vida más larga (CLAUDE.md §2).
    /// Sin _petalSpawnPoints manuales, reparte los pétalos por delante de la cámara activa (varias
    /// profundidades para dar volumen) y les añade una deriva de viento constante en espacio de
    /// cámara, para el efecto "viento cruzando toda la pantalla" (rollo Pocahontas).
    /// </summary>
    private void SpawnPetalDecor()
    {
        if (_petalDecorPrefabs == null || _petalDecorPrefabs.Length == 0) return;
        if (VfxPoolService.Instance == null) return;

        // Viento suave de ambiente acompañando la decoración de pétalos — sutil, no un efecto
        // puntual como una explosión, solo para que la escena no quede completamente muda.
        AudioService.Instance?.PlaySFX("ReinoExit_PetalAmbience", 0.35f);

        if (_petalSpawnPoints != null && _petalSpawnPoints.Length > 0)
        {
            for (int i = 0; i < _petalSpawnPoints.Length; i++)
            {
                Transform point = _petalSpawnPoints[i];
                if (point == null) continue;

                GameObject prefab = _petalDecorPrefabs[i % _petalDecorPrefabs.Length];
                VfxPoolService.Instance.Play(prefab, point.position, point.rotation, _petalsLifetime);
            }
            return;
        }

        Camera cam = Camera.main;
        if (cam == null) return;

        Transform camT = cam.transform;
        Vector3 windVelocityWorld = (camT.right   * _petalWindDirectionCameraSpace.x
                                    + camT.up      * _petalWindDirectionCameraSpace.y
                                    + camT.forward * _petalWindDirectionCameraSpace.z)
                                    .normalized * _petalWindSpeed;

        for (int i = 0; i < _petalScreenCount; i++)
        {
            GameObject prefab = _petalDecorPrefabs[i % _petalDecorPrefabs.Length];

            float depth = Random.Range(_petalScreenDepthRange.x, _petalScreenDepthRange.y);
            float xOff  = Random.Range(-0.5f, 0.5f) * _petalScreenSpread.x;
            float yOff  = Random.Range(-0.5f, 0.5f) * _petalScreenSpread.y;

            Vector3 pos = camT.position + camT.forward * depth + camT.right * xOff + camT.up * yOff;

            // OJO: usar prefab.transform.rotation, no Quaternion.identity. El prefab trae una
            // rotación local de -90° en X (igual que las decoraciones estáticas del Reino en
            // MainWorld, ver Petal01_P/02_P) que orienta el ShapeModule del ParticleSystem; con
            // identity el volumen de emisión queda mal orientado y los pétalos pueden no llegar
            // a verse.
            Transform instance = VfxPoolService.Instance.Play(prefab, pos, prefab.transform.rotation, _petalsLifetime);
            ApplyWind(instance, windVelocityWorld);
        }
    }

    /// Añade una deriva constante en espacio de mundo (velocityOverLifetime) por encima del
    /// revoloteo aleatorio propio del ParticleSystem, para simular una ráfaga de viento sostenida.
    /// También anula la gravedad y el impulso inicial omnidireccional del prefab (InitialModule:
    /// gravityModifier y startSpeed con randomDirectionAmount=1): sin esto, esos dos siguen tirando
    /// de cada pétalo hacia abajo/en cualquier dirección y acaban ganándole visualmente al viento.
    private static void ApplyWind(Transform instance, Vector3 windVelocityWorld)
    {
        if (instance == null) return;

        var systems = instance.GetComponentsInChildren<ParticleSystem>(true);
        for (int i = 0; i < systems.Length; i++)
        {
            var ps = systems[i];

            var main = ps.main;
            main.gravityModifier = 0f;
            main.startSpeed = new ParticleSystem.MinMaxCurve(0.1f, 0.3f);

            var vel = ps.velocityOverLifetime;
            vel.enabled = true;
            vel.space = ParticleSystemSimulationSpace.World;
            vel.x = new ParticleSystem.MinMaxCurve(windVelocityWorld.x);
            vel.y = new ParticleSystem.MinMaxCurve(windVelocityWorld.y);
            vel.z = new ParticleSystem.MinMaxCurve(windVelocityWorld.z);
        }
    }

    private static NPCBehaviourManagerV2 FindPartyMember(string dialogueCharacterId)
    {
        if (string.IsNullOrEmpty(dialogueCharacterId) || !Game.NPC.PlayerParty.HasInstance)
            return null;

        foreach (var member in Game.NPC.PlayerParty.Instance.Members)
        {
            var mgr = member?.NPCManager;
            if (mgr != null && mgr.DialogueCharacterId == dialogueCharacterId)
                return mgr;
        }
        return null;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Fase 0 — Will se detiene; Estela y Liam siguen caminando y se giran
    // ══════════════════════════════════════════════════════════════════════════

    private IEnumerator Co_GroupContinuesAndTurns()
    {
        // Will (el jugador) ya está bloqueado por LockCinematic() dentro de
        // Co_BeginCinematicWithTransition: se para en seco donde estaba.
        bool estelaDone = _estelaManager == null || _estelaContinueTarget == null;
        bool liamDone   = _liamManager   == null || _liamContinueTarget   == null;

        if (!estelaDone)
            _estelaManager.MoveToPosition(_estelaContinueTarget.position, _continueWalkDuration,
                _continueWalkMaxDuration, turn: true, onComplete: () => estelaDone = true);

        if (!liamDone)
            _liamManager.MoveToPosition(_liamContinueTarget.position, _continueWalkDuration,
                _continueWalkMaxDuration, turn: true, onComplete: () => liamDone = true);

        yield return new WaitUntil(() => estelaDone && liamDone);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Fase 1 — Liam pregunta
    // ══════════════════════════════════════════════════════════════════════════

    private IEnumerator Co_LiamPregunta()
    {
        if (_shotLiamClose != null) _cinematicCamera.Cut(_shotLiamClose);
        yield return ShowBubblePaged(_liamManager?.transform, Loc(_keyLiamPregunta),
            _liamPreguntaDuration, _animLiamPregunta, loopAnim: true);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Fase 2 — Will confiesa su miedo
    // ══════════════════════════════════════════════════════════════════════════

    private IEnumerator Co_WillMiedo()
    {
        if (_shotWillClose != null) _cinematicCamera.Cut(_shotWillClose);
        yield return ShowBubblePaged(_willTransform, Loc(_keyWillMiedo),
            _willMiedoDurationPerPage, _animWillMiedo, loopAnim: true);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Fase 3 — Estela lo anima
    // ══════════════════════════════════════════════════════════════════════════

    private IEnumerator Co_EstelaAnimo()
    {
        if (_shotEstelaClose != null) _cinematicCamera.Cut(_shotEstelaClose);
        yield return ShowBubblePaged(_estelaManager?.transform, Loc(_keyEstelaAnimo),
            _estelaAnimoDurationPerPage, _animEstelaAnimo, loopAnim: true);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Fase 4 — Liam lo apoya
    // ══════════════════════════════════════════════════════════════════════════

    private IEnumerator Co_LiamApoyo()
    {
        if (_shotLiamClose != null) _cinematicCamera.Cut(_shotLiamClose);
        yield return ShowBubblePaged(_liamManager?.transform, Loc(_keyLiamApoyo),
            _liamApoyoDurationPerPage, _animLiamApoyo, loopAnim: true);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Fase 5 — Will da las gracias
    // ══════════════════════════════════════════════════════════════════════════

    private IEnumerator Co_WillGracias()
    {
        if (_shotWillClose != null) _cinematicCamera.Cut(_shotWillClose);
        yield return ShowBubblePaged(_willTransform, Loc(_keyWillGracias),
            _willGraciasDuration, _animWillGracias, loopAnim: true);
    }
}
