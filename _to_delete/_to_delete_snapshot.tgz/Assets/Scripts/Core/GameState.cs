using System.Collections.Generic;
using System;
using UnityEngine;

public enum GamePhase
{
    Gameplay,
    PauseMenu,
    MainMenu,
    Dialogue,
    SavePrompt,
    Inventory,
    Equipment,
    QuestMenu,
    Map,
    Shop,
    Cutscene,
    Loading,
    GameOver
}

public static class GameState
{
    private static readonly Dictionary<GamePhase, int> _stack = new Dictionary<GamePhase, int>();
    public static event Action OnChanged;
    
    #if UNITY_EDITOR
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    static void ResetStatics()
    {
        _stack.Clear();
        OnChanged = null;
    }
    #endif

    public static void Push(GamePhase phase)
    {
        if (!_stack.ContainsKey(phase)) _stack[phase] = 0;
        _stack[phase]++;
        OnChanged?.Invoke();
    }

    public static void Pop(GamePhase phase)
    {
        if (!_stack.ContainsKey(phase)) return;
        _stack[phase]--;
        if (_stack[phase] <= 0) _stack.Remove(phase);
        OnChanged?.Invoke();
    }

    public static bool Is(GamePhase phase) => _stack.ContainsKey(phase);

    /// <summary>
    /// Elimina forzosamente una fase del stack independientemente del contador.
    /// Usar solo en recuperaciones de emergencia cuando el stack quedó desbalanceado.
    /// </summary>
    public static void ForceRemove(GamePhase phase)
    {
        if (_stack.ContainsKey(phase))
        {
            _stack.Remove(phase);
            OnChanged?.Invoke();
        }
    }

    /// <summary>
    /// Vacía todo el stack de golpe. Mismo criterio que ForceRemove (usado ya en
    /// GameOverManager para Cutscene) pero para todas las fases a la vez. Usar SOLO en los
    /// puntos de entrada seguros de una sesión (llegar al MainMenu por cualquier camino, o
    /// justo antes de inicializar una partida nueva/continuada) para garantizar que ninguna
    /// fase quede "colgada" (p.ej. Cutscene/Dialogue) si la sesión anterior se cortó de forma
    /// abrupta — p.ej. cerrar la demo a mitad de una cinemática para ir a Créditos.
    /// </summary>
    public static void ResetAll()
    {
        if (_stack.Count == 0) return;
        _stack.Clear();
        OnChanged?.Invoke();
    }

    public static bool IsAny(params GamePhase[] phases)
    {
        for (int i = 0; i < phases.Length; i++)
            if (Is(phases[i])) return true;
        return false;
    }

    // ===== Derived permissions =====
    public static bool CanProcessGameplayInput
        => !IsAny(GamePhase.PauseMenu,
                  GamePhase.MainMenu,
                  GamePhase.Dialogue,
                  GamePhase.SavePrompt,
                  GamePhase.Cutscene,
                  GamePhase.Loading,
                  GamePhase.GameOver,
                  GamePhase.Inventory,
                  GamePhase.Equipment,
                  GamePhase.QuestMenu);

    public static bool CanInteractGlobally
        => !IsAny(GamePhase.PauseMenu,
                  GamePhase.MainMenu,
                  GamePhase.Dialogue,
                  GamePhase.SavePrompt,
                  GamePhase.Cutscene,
                  GamePhase.Loading,
                  GamePhase.Inventory,
                  GamePhase.Equipment,
                  GamePhase.Shop,
                  GamePhase.QuestMenu);

    public static bool CanOpenPause
    {
        get
        {
            bool result = !IsAny(GamePhase.PauseMenu,
                                 GamePhase.MainMenu,
                                 GamePhase.Dialogue,
                                 GamePhase.SavePrompt,
                                 GamePhase.Cutscene,
                                 GamePhase.Loading,
                                 GamePhase.GameOver,
                                 GamePhase.Inventory,
                                 GamePhase.Equipment,
                                 GamePhase.QuestMenu);
            return result;
        }
    }

    public static bool CanOpenInventory
        => CanProcessGameplayInput && !Is(GamePhase.Inventory) && !Is(GamePhase.Equipment) && !Is(GamePhase.QuestMenu);
}
