﻿﻿using System.Collections.Generic;
using UnityEngine;
using TMPro;

/// <summary>
/// Gestor de UI para mostrar habilidades y hechizos desbloqueados del jugador
/// Se conecta automáticamente con GameBootProfile para reflejar cambios
/// </summary>
public class PlayerAbilitiesUI : MonoBehaviour
{
    [Header("Referencias UI - Habilidades")]
    [SerializeField] private Transform abilitiesContainer;
    [SerializeField] private GameObject abilityUIPrefab;
    
    [Header("Referencias UI - Hechizos")]
    [SerializeField] private Transform spellsContainer;
    [SerializeField] private GameObject spellUIPrefab;
    
    [Header("Referencias UI - Información")]
    [SerializeField] private TextMeshProUGUI levelText;
    [SerializeField] private TextMeshProUGUI manaText;
    
    [Header("Configuración")]
    [SerializeField] private bool autoRefresh = true;
    [SerializeField] private bool showDebugInfo; // default false implícito
    [SerializeField] private float refreshInterval = 1f;
    [Header("Presentaciones")]
    [Tooltip("Lista opcional de presentaciones para habilidades. Si está vacía se usarán valores por defecto de AbilityPresentationLookup.")]
    [SerializeField] private List<AbilityPresentation> abilityPresentations = new();
    
    private ManaPool _manaPool;
    
    // Cache para optimización
    private readonly List<GameObject> _abilityUIObjects = new();
    private readonly List<GameObject> _spellUIObjects = new();

    // Evita inicializar dos veces si el evento llega más de una vez
    private bool _initialized;
    
    // Reemplazamos Start/Coroutine por esperar al evento del boot service
    void OnEnable()
    {
        GameBootService.OnProfileReady += HandleProfileReady;
        ProfileReadyDiagnostics.RegisterSubscriber(nameof(PlayerAbilitiesUI));
        if (GameBootService.IsAvailable)
        {
            HandleProfileReady();
        }

        // Suscribirse al evento de re-aplicar preset para refrescar UI cuando corresponda
        PlayerPresetService.OnPresetApplied += OnPresetAppliedHandler;
    }

    void OnDisable()
    {
        GameBootService.OnProfileReady -= HandleProfileReady;
        if (autoRefresh)
        {
            CancelInvoke(nameof(RefreshAll));
        }

        // Unsubscribe del evento
        PlayerPresetService.OnPresetApplied -= OnPresetAppliedHandler;
    }

    private void HandleProfileReady()
    {
        if (_initialized) return;

        FindPlayerComponents();
        RefreshAll();
        
        if (autoRefresh)
        {
            InvokeRepeating(nameof(RefreshAll), refreshInterval, refreshInterval);
        }

        _initialized = true;
        GameBootService.OnProfileReady -= HandleProfileReady;
    }

    private void OnPresetAppliedHandler()
    {
        // Refrescar UI cuando se re-aplica el preset (sólo si ya inicializó la UI)
        if (_initialized) RefreshAll();
    }

    private void FindPlayerComponents()
    {
        // Obtener ManaPool del jugador directamente desde el ServiceLocator
        _manaPool = ServiceLocator.Get<ManaPool>(false);
        
        if (_manaPool == null && showDebugInfo)
        {
            Debug.LogWarning("[PlayerAbilitiesUI] No se encontró ManaPool en la escena");
        }
    }
    
    public void RefreshAll()
    {
        var bootProfile = GameBootService.Profile;
        if (bootProfile == null) return;
        
        var preset = bootProfile.GetActivePresetResolved();
        if (preset == null) return;
        
        RefreshAbilities(preset);
        RefreshSpells(preset);
        RefreshStats(preset);
    }
    
    /// <summary>
    /// Devuelve el slot pooled en "index" (reactivándolo) o instancia uno nuevo si el pool es
    /// más corto. Se llama desde RefreshAbilities/RefreshSpells, que corren cada segundo vía
    /// InvokeRepeating — reutilizar evita Destroy+Instantiate continuo mientras la UI está abierta.
    /// </summary>
    private static GameObject GetOrCreateSlot(List<GameObject> pool, GameObject prefab, Transform container, int index)
    {
        if (index < pool.Count)
        {
            var existing = pool[index];
            if (existing != null)
            {
                existing.SetActive(true);
                return existing;
            }
        }

        var uiObject = Instantiate(prefab, container);
        if (index < pool.Count)
            pool[index] = uiObject;
        else
            pool.Add(uiObject);
        return uiObject;
    }

    private static void HideExtraSlots(List<GameObject> pool, int usedCount)
    {
        for (int i = usedCount; i < pool.Count; i++)
        {
            if (pool[i] != null) pool[i].SetActive(false);
        }
    }

    private void RefreshAbilities(PlayerPresetSO preset)
    {
        if (abilitiesContainer == null || abilityUIPrefab == null) return;

        int used = 0;

        // Crear UI para habilidades desbloqueadas.
        // Compatibilidad: si el preset tiene una lista `unlockedAbilities` (enum-based), la usamos.
        if (preset.unlockedAbilities != null && preset.unlockedAbilities.Count > 0)
        {
            foreach (var abilityId in preset.unlockedAbilities)
            {
                var uiObject = GetOrCreateSlot(_abilityUIObjects, abilityUIPrefab, abilitiesContainer, used);

                // Resolver presentación (título, descripción, icono)
                var pres = AbilityPresentationLookup.Resolve(abilityId, abilityPresentations);

                // Configurar el objeto UI: buscar texto e imagen si existen
                var text = uiObject.GetComponentInChildren<TextMeshProUGUI>();
                if (text != null)
                {
                    text.text = pres.title;
                }

                var img = uiObject.GetComponentInChildren<UnityEngine.UI.Image>();
                if (img != null)
                {
                    img.sprite = pres.icon;
                    img.enabled = pres.icon != null;
                }

                used++;
            }
        }
        else
        {
            // Si no hay lista enum-based, leer las booleans de PlayerAbilities y mostrarlas
            var abilities = preset.abilities ?? new PlayerAbilities();
            var keys = new System.Collections.Generic.List<AbilityKey>();
            if (abilities.swim) keys.Add(AbilityKey.Swim);
            if (abilities.jump) keys.Add(AbilityKey.Jump);
            if (abilities.climb) keys.Add(AbilityKey.Climb);
            if (abilities.magic) keys.Add(AbilityKey.Magic);
            if (abilities.fly) keys.Add(AbilityKey.Fly);

            foreach (var key in keys)
            {
                var uiObject = GetOrCreateSlot(_abilityUIObjects, abilityUIPrefab, abilitiesContainer, used);
                var pres = AbilityPresentationKeyLookup.Resolve(key, null);

                var text = uiObject.GetComponentInChildren<TextMeshProUGUI>();
                if (text != null) text.text = pres.title;

                var img = uiObject.GetComponentInChildren<UnityEngine.UI.Image>();
                if (img != null)
                {
                    img.sprite = pres.icon;
                    img.enabled = pres.icon != null;
                }

                used++;
            }
        }

        HideExtraSlots(_abilityUIObjects, used);

        if (showDebugInfo)
        {
            Debug.Log($"[PlayerAbilitiesUI] Abilities refreshed: {preset.unlockedAbilities?.Count ?? 0} abilities");
        }
    }

    private void RefreshSpells(PlayerPresetSO preset)
    {
        if (spellsContainer == null || spellUIPrefab == null) return;

        int used = 0;

        // Crear UI para hechizos desbloqueados
        if (preset.unlockedSpells != null)
        {
            foreach (var spellId in preset.unlockedSpells)
            {
                var uiObject = GetOrCreateSlot(_spellUIObjects, spellUIPrefab, spellsContainer, used);

                // Configurar el objeto UI
                var text = uiObject.GetComponentInChildren<TextMeshProUGUI>();
                if (text != null)
                {
                    text.text = spellId.ToString();
                }

                used++;
            }
        }

        HideExtraSlots(_spellUIObjects, used);

        if (showDebugInfo)
        {
            Debug.Log($"[PlayerAbilitiesUI] Spells refreshed: {preset.unlockedSpells?.Count ?? 0} spells");
        }
    }
    
    private void RefreshStats(PlayerPresetSO preset)
    {
        // Actualizar nivel
        if (levelText != null)
        {
            string levelFmt = LocalizationManager.Instance != null
                ? LocalizationManager.Instance.Get("ABILITIES_LEVEL_LABEL", "Nivel: {0}")
                : "Nivel: {0}";
            levelText.text = string.Format(levelFmt, preset.level);
        }

        // Actualizar maná
        if (manaText != null)
        {
            // Ocultar el contador de maná si el preset indica que el jugador NO tiene la ability de magia
            if (preset.abilities != null && !preset.abilities.magic)
            {
                manaText.gameObject.SetActive(false);
            }
            else
            {
                // Mostrar/actualizar el texto de maná según el ManaPool si existe, o según el preset
                manaText.gameObject.SetActive(true);
                string manaFmt = LocalizationManager.Instance != null
                    ? LocalizationManager.Instance.Get("ABILITIES_MANA_LABEL", "Maná: {0}/{1}")
                    : "Maná: {0}/{1}";
                if (_manaPool != null)
                {
                    manaText.text = string.Format(manaFmt, _manaPool.Current.ToString("0"), _manaPool.Max.ToString("0"));
                }
                else
                {
                    manaText.text = string.Format(manaFmt, preset.currentMP.ToString("0"), preset.maxMP.ToString("0"));
                }
            }
        }
    }
    
    // Métodos públicos para refrescar componentes individuales
    public void RefreshAbilities()
    {
        var preset = GameBootService.Profile?.GetActivePresetResolved();
        if (preset != null) RefreshAbilities(preset);
    }
    
    public void RefreshSpells()
    {
        var preset = GameBootService.Profile?.GetActivePresetResolved();
        if (preset != null) RefreshSpells(preset);
    }
    
    public void RefreshStats()
    {
        var preset = GameBootService.Profile?.GetActivePresetResolved();
        if (preset != null) RefreshStats(preset);
    }
    
    // Método para debugging
    [ContextMenu("Refresh All (Debug)")]
    private void DebugRefresh()
    {
        RefreshAll();
    }
}
